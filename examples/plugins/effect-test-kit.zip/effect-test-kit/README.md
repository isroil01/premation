# Effect Test Kit

Four effects. Apply each to a layer with some contrast in it and check the
column on the right.

| Effect | What it proves | Looks broken if… |
|---|---|---|
| 0 · Edges | The ordinary single-pass path still works | nothing happens at all — then the problem is not the new work |
| 1 · Blur | A multi-pass chain runs BOTH passes, and `texelSize` arrived | it blurs in one axis only, or not at all |
| 2 · Bloom | Quarter-scale passes, and `reads: "both"` | the layer turns into a soft smear with no sharp content — that is the composite adding the blur to itself instead of to the original |
| 3 · Spotlight | A `point` parameter packs as a vec2, 8-byte aligned, at offset 96 | the bright spot does not move when you change Centre X/Y, or it jumps when you drag Radius instead |

The Centre default (480, 270) is centred for a 960×540 composition — on a
1080p one the spot starts in the upper left. That is expected: the coordinate
is in the effect target's pixels, which is the composition on a 2D layer.

Turn the Blur radius up to 20+ on a 3D layer to check the declared spread: the
blur should fade out smoothly rather than stopping at a hard rectangular edge.
Blur declares `spread: radius × 2.5` (50px at radius 20) and Bloom `× 4`.

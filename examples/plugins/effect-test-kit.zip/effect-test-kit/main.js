/**
 * Nothing runs at runtime. Every effect here is DATA: the host read it out of
 * plugin.json, generated the bindings and the vertex stage, compiled one
 * pipeline per pass, and draws them. None of that involves this file — which is
 * why these effects keep working with this worker stopped, and in a project
 * opened by someone who never installed the plugin.
 */
export function activate() {}
